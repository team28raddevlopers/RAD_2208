<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

  public function __construct(){/*this is the constructor*/
    parent::__construct();
    $this->load->helper('url');/*loads the url helper */
    $this->load->model('User_Model');/*loads the User_Model into controller*/
  }

  public function addbookload(){

    $this->load->view('AddBook_form');/*loads the view of add booking*/

  }
  function addbooking()  {

    $data = array(  /*store the data posted by the addbooking form(user inserted), in an array*/
      'UserID'     => $this->input->post('UD'),
      'date1'  => $this->input->post('date1'),
      'Time_from'   => $this->input->post('ftime'),
      'Time_to'   => $this->input->post('ttime'),
    );
    $this->User_Model->addbooking($data);/*pass the data in the array into the addbooking
    function in User_Model to update the database*/
    redirect('User/addbookload');/*reload the addbook form again*/
  }

  public function bookcoachload(){

    $this->displaycoaches();/*load the view of booking a coach*/
  }

  function bookcoach(){

    $data = array(/*store the data posted by the book coach form in an array*/
      'CoachID'     => $this->input->post('CID'),
      'date1'  => $this->input->post('date'),
      'Time_from'   => $this->input->post('ftime'),
      'Time_to'   => $this->input->post('ttime'),

    );
    $this->User_Model->bookcoach($data);/*pass the data in the array into the addbooking
    function in User_Model to update the database*/
    redirect('User/bookcoachload');/*reload the bookcoach form again*/

  }

  public function displaycoaches(){/*display name and the id of the registered coaches in the system*/

    $result['data']=$this->User_Model->displaycoaches();/*call the model function to retrieve coach data
    and store those records in a result array*/
    $this->load->view('BookCoach_form',$result);/*since this function only includes a call to the model and get its data,
    redirecting to this will not show any interface to the user.so here controller calls again the coach booking form to solve that*/
  }

  public function viewload(){

    $this->displaybookings();/*load the view include bookings*/
  }
  function removebooking(){/* function to remove a booking from the database*/

    $bid2=$this->input->get('bid2');/*get the booking id entered at the view form*/
    $this->User_Model->removebooking($bid2);/*call the removebooking function in the
    model file,passing the booking id as a parameter*/
    redirect('User/viewload');/*load the view include removeing bookings */
  }

  public function displaybookings(){/*display details of the bookings done by the user*/

    $result['data']=$this->User_Model->displaybookings();/*call the model function to retrieve booking data
    and store those records in a result array*/
    $this->load->view('View_form',$result);/*since this function only includes a call to the model and get its data,
    redirecting to this will not show any interface to the user.so here controller calls again the view of bookings to solve that*/
  }

}
?>
