<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coach extends CI_Controller {

  public function __construct(){/*this is the constructor*/
    parent::__construct();
    $this->load->helper('url');/*loads the url helper */
    $this->load->model('User_Model');/*loads the User_Model into controller*/

  }

  function currentbookingsload(){/*loads the current bookings view*/
    $this->displaycurrent();/*calls the controller function which decides what the user interface should include*/
  }

  function rejectbooking(){/* function to call the rejectbooking model function to
    update a booking status as cancelled*/
    $bid2=$this->input->get('bid2');/*get the booking id from the form input*/
    $this->Coach_Model->rejectbooking($bid2);/*calls the model function to update booking*/
    redirect('Coach/currentbookingsload');/*reloads to the view define by currentbookings load*/
  }

  function displaycurrent(){/*function to display current bookings*/
    $result['data']=$this->Coach_Model->displaycurrent();/*call the model function to retrieve current bookings data
    and store those records in a result array*/
    $this->load->view('CurrentBookings_form',$result);/*since this function only includes a call to the model and get its data,
    redirecting to this will not show any interface to the user.so here controller calls again the current booking form to solve that*/

  }
  function pendingbookingsload(){/*loads the pending bookings view*/
    $this->displaypending();/*calls the controller function which decides what the user interface should include*/

  }

  function accept_pending_booking()  {/* function to call the confirmbooking model function to
    update a booking status as cancelled*/
    $bid=$this->input->get('bid');/*get the booking id from the form input*/
    $this->Coach_Model->confirmbooking($bid);/*calls the model function to update booking*/
    redirect('Coach/pendingbookingsload');/*reloads to the view define by pendingbookings load*/

  }

  function reject_pending_booking()  {/* function to call the rejectbooking model function to
    update a booking status as cancelled*/
    $bid2=$this->input->get('bid2');/*get the booking id from the form input*/
    $this->Coach_Model->rejectbooking($bid2);/*calls the model function to update booking*/
    redirect('Coach/pendingbookingsload');/*reloads to the view define by pendingbookings load*/
  }

  function displaypending(){/*function to display pending bookings*/
    $result['data']=$this->Coach_Model->displaypending();/*call the model function to retrieve pending bookings data
    and store those records in a result array*/
    $this->load->view('PendingBookings_form',$result);/*since this function only includes a call to the model and get its data,
    redirecting to this will not show any interface to the user.so here controller calls again the pending booking form to solve that*/
  }

  function cancelledbookingsload(){/*loads the pending bookings view*/

    $this->displaycancelled();  /*calls the controller function which decides what the user interface should include*/

  }

  function accept_cancelled(){/* function to call the confirmbooking model function to
    update a booking status as cancelled*/
    $bid=$this->input->get('bid');/*get the booking id from the form input*/
    $this->Coach_Model->confirmbooking($bid);/*calls the model function to update booking*/
    redirect('Coach/cancelledbookingsload');/*reloads to the view define by ;cancelledbookings load*/
  }

  function displaycancelled(){
    $result['data']=$this->Coach_Model->displaycancelled();/*call the model function to retrieve cancelled bookings data
    and store those records in a result array*/
    $this->load->view('CancelledBookings_form',$result);/*since this function only includes a call to the model and get its data,
    redirecting to this will not show any interface to the user.so here controller calls again the cancelled booking form to solve that*/
  }

}

?>
