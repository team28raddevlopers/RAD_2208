<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller {

  function index(){
  	$this->load->view('front');
	}

 function userload(){
	$this->load->view('user');
}

function coachload(){
	$this->load->view('coach');
	}
}
?>