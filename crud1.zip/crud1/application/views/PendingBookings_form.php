<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Iconic Tennis Court</title>
  </head>
  <body>
    <div class="container">
        <br><br>
        <nav class="navbar navbar-expand-md bg-dark navbar-dark justify-content-center sticky-top">
            <!-- Brand -->
            <a class="navbar-brand" href="#">Tennis Court</a>
            
                <!-- Toggler/collapsibe Button -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            
                <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="../Coach/currentbookingsload">Current Bookings</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="../Coach/pendingbookingsload">Pending Bookings</a>
                    </li> 
<li class="nav-item">
                        <a class="nav-link active" href="../Coach/cancelledbookingsload">Cancelled Bookings</a>
                    </li> 
                </ul>
            </div> 
        <button class="btn btn-light">Log Out</button>
        </nav>
        <br><br>
        
<article class="expanded">



			<div style="width:60%;height:300px; margin-top: 0%;overflow:auto; float:right;">
            <caption class="title"><h5><center>Your pending Bookings</center></h5></caption>
			<table class="data-table" width=100%>

			
			<thead>
				<tr>
                	<th>No</th>
					<th>Booking NO</th>
					<th>User ID</th>
					<th>Date</th>
                    <th>From</th>
                    <th>To</th>

				</tr>
			</thead>
			<tbody>
			<?php
			$no=1;
	
  foreach($data as $row)
  {
				//$amount  = $row['amount'] == 0 ? '' : number_format($row['amount']);

				echo '<tr>';
				echo '<td>'.$no.'</td>';
				echo '<td>'.$row->Booking_no.'</td>';
				echo '<td>'.$row->UserID.'</td>';
				echo '<td>'.$row->date1.'</td>';
				echo '<td>'.$row->Time_from.'</td>';
				echo '<td>'.$row->Time_to.'</td>';
				echo '</tr>';		
				
			$no++;
	

			}?>

			</tbody>
			<tfoot>
				<tr>
					<th colspan="5">TOTAL</th>
					<th><?=number_format($no -1)?></th>
				</tr>
			</tfoot>
		</table>

	</div>
    </article>

        <hr>
        <br><br>
        <div class="col-sm-6">
            <div class="row">
                <h3>Accept Bookings</h3>
                <hr>
                <form action="<?php echo  site_url('Coach/accept_pending_booking'); ?>" class="form-inline was-validated">
                    <div class="form-group">
                        <label for="bid">Booking ID:</label>
                        <input type="text" class="form-control ml-sm-2" id="bid" placeholder="Enter booking ID" name="bid" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <button type="submit" class="btn btn-primary" >Submit</button>
                </form>
            </div>
<br><br>
            <div class="row">
                <h3>Reject Bookings</h3>
                <hr>
                <form action="<?php echo  site_url('Coach/reject_pending_booking'); ?>" class="form-inline was-validated" onsubmit="updated()">
                    <div class="form-group">
                        <label for="bid2">Booking ID:</label>
                        <input type="text" class="form-control ml-sm-2" id="bid2" placeholder="Enter booking ID" name="bid2" required>
                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>
                    <button type="submit" class="btn btn-primary" >Submit</button>
                </form>
            </div>
        </div>
    </div>
   

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="alerts.js"></script>  
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
