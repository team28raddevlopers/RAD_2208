<?php
class Coach_Model extends CI_Model
{

	function rejectbooking($bid2){

		$data = [
			'status' => 'cancelled',
		];/*put the data as how they should be updated into the $data array */
		$this->db->where('Booking_no',$bid2);/*filter out the record to be updated */
		$sql_query=$this->db->update('coach_bookings', $data);/*update the particular record in the database */

	}

	function displaycurrent(){

		$array=array('CoachID' => 'c001','status'=>'confirmed');/*store the data UserID=rusiri in the array..Here c001
		should be replaced by the logged coach.Since login part is not in my scope, i hardcoded it here*/
		$query = $this->db->get_where('coach_bookings', $array);/*get the selected records from coach_bookings table*/
		return $query->result();/*return the resulting records*/

	}

	function confirmbooking($bid){

		$data = [
			'status' => 'confirmed',
		];/*put the data as how they should be updated into the $data array */
		$this->db->where('Booking_no',$bid);/*finds the records which should be changed*/
		$this->db->update('coach_bookings', $data);/*update the records with the data in the array */

	}
	function displaypending(){

		$array=array('CoachID' => 'c001','status'=>'pending');/*store the data UserID=rusiri in the array..Here c001
		should be replaced by the logged coach.Since login part is not in my scope, i hardcoded it here*/
		$query = $this->db->get_where('coach_bookings', $array);/*get the particular records from coach_bookings table*/
		return $query->result();/*return the resulting records*/

	}

	function displaycancelled(){

		$array=array('CoachID' => 'c001','status'=>'cancelled');/*store the data UserID=rusiri in the array..Here c001
		should be replaced by the logged coach.Since login part is not in my scope, i hardcoded it here*/
		$query = $this->db->get_where('coach_bookings', $array);/*get the particular records from coach_bookings table*/
		return $query->result();/*return the resulting records*/

	}
}
?>
