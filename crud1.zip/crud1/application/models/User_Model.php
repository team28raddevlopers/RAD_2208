<?php
class User_Model extends CI_Model {
	function addbooking($data){
		$query=$this->db->where("$data.Time_from BETWEEN $Time_from AND $Time_to OR $data.Time_to BETWEEN $Time_from AND $Time_to");
		/*chacks whether the booking ime is already reserved*/
		if(!$query)/*If there are no booking records for the given time*/
		$this->db->insert('current_bookings',$data);/*insert data into current_bookings table*/
		else {
			echo "Booking time is not vacent";
		}
	}

	function bookcoach($data){

		$this->db->insert('coach_bookings',$data);/*insert data into coach_bookings table*/

	}

	function displaycoaches(){

		$query =$this->db->get_where('coach',);/*load coach details from the database*/
		return $query->result();/*return the particular records*/
	}

	function removebooking($bid2){

		$sql_query=$this->db->where('Booking_no', $bid2)->delete('current_bookings');
		/*deletes records from current_bookings table where Booking_no = the id of the booking inserted to be removed*/
	}


	function displaybookings(){
		
		$array=array('UserID' => 'rusiri');/*store the data UserID=rusiri in the array..Here rusiri
		should be replaced by the logged user.Since login part is not in my scope, i hardcoded it here*/
		$query = $this->db->get_where('current_bookings', $array);/*get the records from current_bookings
		table which satisfies the condition stored in the array*/
		return $query->result();/*return the paticular records*/

	}

}

?>
