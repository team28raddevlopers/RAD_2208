<?php
class Reg_Model extends CI_Model{
	public function dbconf(){
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
		define('DB_SERVER', 'localhost');
		define('DB_USERNAME', 'root');
		define('DB_PASSWORD', '');
		define('DB_NAME', 'myapp');

		/* Attempt to connect to MySQL database */
		$link = mysqli_connect(DB_SERVER, 		DB_USERNAME, DB_PASSWORD, DB_NAME);
 
		// Check connection
		if($link === false){
    	die("ERROR:Couldnotconnect.".mysqli_connect_error());
		}
	}
}
?>
